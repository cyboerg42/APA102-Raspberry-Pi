#!/bin/bash
# bash trap command
trap bashtrap INT
# bash clear screen command
clear;

bashtrap()
{
    echo "CTRL+C Detected !...executing bash trap !"
    exit
}
while true
do
for a in `seq 0 560`; do
    ./frame $a
done
done
